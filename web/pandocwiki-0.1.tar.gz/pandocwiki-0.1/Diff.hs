module Diff ( Change (..), applyChanges, diffsFrom ) where

-- http://urchin.earth.li/darcs/igloo/lcs/Data/List/LCS
import Data.List.LCS.HuntSzymanski (lcs) 
import Data.List (break)
import Data.Char (ord)
import Test.QuickCheck

-- | A changeset is represented as a set of instructions to insert,
-- delete, or skip (keep) characters in the source string.
data Change a = Ins [a] | Keep Int | Del Int deriving (Eq, Show, Read)

-- | Apply a changeset to a list.
applyChanges :: [Change a] -> [a] -> [a]
applyChanges changes source = 
    snd $ foldl applyChange (source, []) changes 
    where applyChange (source, dest) (Ins x) = (source, dest ++ x)
          applyChange (source, dest) (Keep n) = let common = take n source
                                                in  (drop n source, dest ++ common) 
          applyChange (source, dest) (Del n) = (drop n source, dest) 

adjust :: Eq a => ([a], [a], [Change a]) -> a -> ([a], [a], [Change a])
adjust (left, right, diffs) elt = 
    let (lfront, lback) = break (== elt) left
        (rfront, rback) = break (== elt) right
        dels = if null lfront then [] else [Del (length lfront)]
        inss = if null rfront then [] else [Ins rfront]
    in  (tail lback, tail rback, 
         diffs ++ dels ++ inss ++ [(Keep 1)])

-- | Generate list of changes needed to get from source to target list.
diffsFrom :: Ord a => [a] -> [a] -> [Change a]
diffsFrom left right =
    let common = lcs left right 
        (left', right', diffs') = foldl adjust (left, right, []) common 
    in  diffs' ++ (if null left' then [] else [Del (length left')]) ++ 
        (if null right' then [] else [Ins right']) 

-- Tests

testDiff = quickCheck ((\x y -> (applyChanges (diffsFrom x y) x) == y) :: [Int] -> [Int] -> Bool)

